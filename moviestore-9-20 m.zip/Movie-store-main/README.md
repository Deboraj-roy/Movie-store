# Movie-store
Movie store MVC ASP .NET
   Live 01:http://deb.somee.com
   Live 02:https://kartik.bsite.net/
